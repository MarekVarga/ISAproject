//////////////////////////////////////////////////////////////
/*                                                          */
/*      Project for ISA course - HTTP bulletin board        */
/*      Header file for API                                 */
/*                                                          */
/*      Author: Marek Varga                                 */
/*      Login: xvarga14                                     */
/*                                                          */
//////////////////////////////////////////////////////////////
#ifndef PROJECT_API_H
#define PROJECT_API_H

// const specifying maximum number of pending connections
int MAX_NUMBER_OF_PENDING_CONNECTIONS = 10;

// HTTP header fields
char* HTTP_VERSION = "HTTP/1.1";
char* CONTENT_TYPE = "Content-Type:text/plain";
char* CONTENT_LENGTH = "Content-Length: ";

// structure for all the boards
struct Boards {
    struct Board* board;
};

// structure for board
struct Board {
    char* name;
    int isInitialized;
    struct BoardContent* content;
    struct Board* nextBoard;
};

// structure for boards's content
struct BoardContent {
    int id;
    char* content;
    struct BoardContent* nextContent;
};

// structure for HTTP header
struct HttpHeader {
    char* method;
    char* url;
    char* host;
    int contentLength;
};

// API
char* GET_BOARDS = "GET /boards";
char* POST_BOARDS = "POST /boards/";
char* DELETE_BOARDS = "DELETE /boards/";
char* GET_BOARD = "GET /board/";
char* POST_BOARD = "POST /board/";
char* DELETE_BOARD = "DELETE /board/";
char* PUT_BOARD = "PUT /board/";

// HTTP response codes
int RESPONSE_CODE_200 = 200;
int RESPONSE_CODE_201 = 201;
int RESPONSE_CODE_400 = 400;
int RESPONSE_CODE_404 = 404;
int RESPONSE_CODE_409 = 409;

// HTTP response header
char* RESPONSE_200 = "HTTP/1.1 200 OK\r\n";
char* RESPONSE_201 = "HTTP/1.1 201 CREATED\r\n";
char* RESPONSE_400 = "HTTP/1.1 400 BAD REQUEST\r\n";
char* RESPONSE_404 = "HTTP/1.1 404 NOT FOUND\r\n";
char* RESPONSE_409 = "HTTP/1.1 409 CONFLICT\r\n";

// exit codes
int EXIT_CODE_0 = 0;
int EXIT_CODE_1 = 1;

#endif //PROJECT_API_H
